package com.sict.expenses.model

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

/**
 * Created by µðšţãƒâ ™ on 4/3/2019.
 * ->
 */
@Entity
data class Expenses(@PrimaryKey var id: Int, var date: Long, var wallet: Int, var expenses: Int)