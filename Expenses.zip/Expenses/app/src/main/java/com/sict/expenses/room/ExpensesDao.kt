package com.sict.expenses.room

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import com.sict.expenses.model.Expenses

/**
 * Created by µðšţãƒâ ™ on 4/3/2019.
 * ->
 */
@Dao
interface ExpensesDao {
    @Insert
    fun insertExpenses(expenses: Expenses)

}